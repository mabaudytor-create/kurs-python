# ---------------------------------------------
# check_fastapi_simple.ps1
# Proste sprawdzenie, czy FastAPI działa
# ---------------------------------------------

# 1️⃣ Uruchom Docker Compose w tle
Write-Host "Uruchamiam Docker Compose..."
docker compose up -d --build

# 2️⃣ Czekaj na FastAPI (localhost:8000/docs)
$fastApiUrl = "http://localhost:8000/docs"
$maxRetries = 30
$retry = 0
$ready = $false

Write-Host "Czekam na uruchomienie FastAPI na $fastApiUrl ..."

while (-not $ready -and $retry -lt $maxRetries) {
    try {
        $response = Invoke-WebRequest -Uri $fastApiUrl -UseBasicParsing -TimeoutSec 2
        if ($response.StatusCode -eq 200) {
            $ready = $true
        }
    } catch {
        Start-Sleep -Seconds 2
        $retry++
    }
}

# 3️⃣ Wynik
if ($ready) {
    Write-Host "✅ FastAPI jest dostępne pod $fastApiUrl"
} else {
    Write-Host "❌ FastAPI nie uruchomiło się w czasie oczekiwania."
    exit 1
}
